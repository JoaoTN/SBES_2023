# qualidade_de_software_2021.1
Trabalho final da disciplina de Qualidade de Software, onde foi realizado a refatoração do sistema Clínica Life Fisioterapia e Estética
