package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum SituacaoComportamento {

	TODOS, NAO_ASSOCIADOS, ASSOCIADOS, NAO_CONSOLIDADOS, CONSOLIDADOS, ORIGINAIS, EXCLUIDOS, EDITADOS;
	
}