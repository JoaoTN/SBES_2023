package br.ufc.quixada.npi.gestaocompetencia.exception;

public class GestaoCompetenciaException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public GestaoCompetenciaException(String message) {
		super(message);
	}

}
