package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum TipoAreaPerfil {

    PESQUISA, PROFISSIONAL, CULTURA, ESPORTE;
}
