package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum SituacaoResponsabilidade {
	TODAS, NAO_VALIDADAS, VALIDADAS, EXCLUIDAS, NAO_EDITADAS, EDITADAS, NAO_CONSOLIDADAS, CONSOLIDADAS
}
