package br.ufc.quixada.npi.gestaocompetencia.model;

public interface IPermissaoNormalizacao {
	boolean hasEditingPermission(Usuario usuario);
}
