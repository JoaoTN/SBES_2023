package br.ufc.quixada.npi.gestaocompetencia.controller;

public interface FormacaoAcademicaController {
	
}
