package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum CategoriaComportamento {


    GOSTO, NAO_GOSTO, IDEAL;

}
