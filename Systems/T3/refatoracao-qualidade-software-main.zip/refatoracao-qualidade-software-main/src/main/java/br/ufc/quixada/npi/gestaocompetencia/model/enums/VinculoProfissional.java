package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum VinculoProfissional {

	TECNICO_ADMINISTRATIVO, DOCENTE;
}
