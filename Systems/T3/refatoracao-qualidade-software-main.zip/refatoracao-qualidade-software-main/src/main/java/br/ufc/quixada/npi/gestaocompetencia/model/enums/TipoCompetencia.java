package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum TipoCompetencia {

    TECNICA, COMPORTAMENTAL;

}
