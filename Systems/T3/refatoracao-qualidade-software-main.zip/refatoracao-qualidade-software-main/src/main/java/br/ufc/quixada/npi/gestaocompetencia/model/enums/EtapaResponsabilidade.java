package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum EtapaResponsabilidade {
	GERAL, EDITADO, VALIDADO, CONSOLIDADO
}
