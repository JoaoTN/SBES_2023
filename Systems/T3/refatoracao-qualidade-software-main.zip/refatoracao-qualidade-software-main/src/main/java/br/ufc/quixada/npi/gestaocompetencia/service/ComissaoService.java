package br.ufc.quixada.npi.gestaocompetencia.service;

import br.ufc.quixada.npi.gestaocompetencia.model.Usuario;

public interface ComissaoService {

	boolean isMembroComissao(Usuario usuario);
	
}
