package br.ufc.quixada.npi.gestaocompetencia.model.enums;

public enum Lotacao {

	UNIDADE, SUBUNIDADE, SETOR;
}
