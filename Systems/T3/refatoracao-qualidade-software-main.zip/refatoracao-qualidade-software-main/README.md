# back-gestao-competencias
Experimento Refatoração UFC
