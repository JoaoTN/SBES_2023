
--
-- TOC entry 190 (class 1259 OID 249312)
-- Name: coautores_trabalho; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bolsistas_trablho (
    bolsista_id bigint NOT NULL,
    trabalho_id bigint NOT NULL
);

