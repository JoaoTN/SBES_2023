package ufc.quixada.npi.contest.model;

public class PresencaJsonWrapper {
	private Long trabalhoId;

	public Long getTrabalhoId() {
		return trabalhoId;
	}
	public void setTrabalhoId(Long trabalhoId) {
		this.trabalhoId = trabalhoId;
	}
}