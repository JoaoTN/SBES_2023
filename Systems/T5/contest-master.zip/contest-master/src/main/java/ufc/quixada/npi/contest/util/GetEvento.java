package ufc.quixada.npi.contest.util;

import ufc.quixada.npi.contest.model.Evento;

public class GetEvento {
	public static Long getId(Evento evento) {
		return evento.getId();
	}

}
