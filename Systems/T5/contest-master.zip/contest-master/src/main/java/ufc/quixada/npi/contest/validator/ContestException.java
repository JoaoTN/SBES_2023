package ufc.quixada.npi.contest.validator;

public class ContestException extends Exception {

    public ContestException(String message) {
        super(message);
    }

    public ContestException(String message, Throwable cause) {
        super(message, cause);
    }

}
