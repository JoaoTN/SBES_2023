package ufc.quixada.npi.contest.util;

import ufc.quixada.npi.contest.model.Arquivo;

public class GetArquivo {
	public static Integer getId(Arquivo arquivo) {
		return arquivo.getId();
	}
}
