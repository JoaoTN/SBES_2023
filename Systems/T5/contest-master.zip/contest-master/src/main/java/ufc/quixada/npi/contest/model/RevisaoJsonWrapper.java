package ufc.quixada.npi.contest.model;

public class RevisaoJsonWrapper {
	private Long revisorId;
	private Long trabalhoId;

	public Long getRevisorId() {
		return revisorId;
	}
	public void setRevisorId(Long revidorId) {
		this.revisorId = revidorId;
	}
	public Long getTrabalhoId() {
		return trabalhoId;
	}
	public void setTrabalhoId(Long trabalhoId) {
		this.trabalhoId = trabalhoId;
	}
}
