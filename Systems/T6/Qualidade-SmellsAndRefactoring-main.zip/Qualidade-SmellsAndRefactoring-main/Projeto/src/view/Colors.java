package view;

import java.awt.Color;
/**
 * 
 * @author lucas b
 *	
 */
public class  Colors {

	public static Color COLOR_MAIN = new Color(102,45,145);
	public static Color COLOR_BUTTON = new Color(86,35,130);
	public static Color COLOR_HOVER = new Color(108,65,165);
	
}
