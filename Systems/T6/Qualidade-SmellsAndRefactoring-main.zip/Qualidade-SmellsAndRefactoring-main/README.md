# Qualidade-SmellsAndRefactoring
Trabalho de Qualidade de Software, que tem como intuito refatorar 40 Code Smells em Java OO

Projeto de origem: https://github.com/breitembach/SisCom-Java
