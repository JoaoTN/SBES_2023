package data;

public enum OrderStatus {
	UNPAID, PAID, CANCLE
}
