package data;

public enum FlightStatus {
	UNPUBLISHED, FULL, AVAILABLE, TERMINATE
}
