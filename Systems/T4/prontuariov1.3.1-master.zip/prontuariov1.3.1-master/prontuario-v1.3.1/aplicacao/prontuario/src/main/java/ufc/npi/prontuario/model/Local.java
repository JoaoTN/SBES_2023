package ufc.npi.prontuario.model;

public enum Local {
	DENTE, FACE, GERAL;
}
