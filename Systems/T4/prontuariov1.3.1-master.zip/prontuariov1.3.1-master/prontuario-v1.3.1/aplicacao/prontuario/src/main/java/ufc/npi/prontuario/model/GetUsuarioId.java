package ufc.npi.prontuario.model;

public class GetUsuarioId {
	
	public static Integer mostrarIdUsuario(Usuario usuario) {
		return usuario.getId();
	}

}
