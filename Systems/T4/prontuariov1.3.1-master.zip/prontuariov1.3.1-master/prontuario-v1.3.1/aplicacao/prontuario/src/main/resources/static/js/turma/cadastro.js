$(document).ready(function() {
	$('input[name="_professores"]').remove();
});