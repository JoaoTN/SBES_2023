package ufc.npi.prontuario.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ufc.npi.prontuario.model.ItemAvaliacao;

public interface ItemAvaliacaoRepository extends JpaRepository<ItemAvaliacao, Integer>{

}
