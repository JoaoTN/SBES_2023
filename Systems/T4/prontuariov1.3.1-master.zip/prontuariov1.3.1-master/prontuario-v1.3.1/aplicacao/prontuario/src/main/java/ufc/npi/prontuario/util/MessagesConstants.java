package ufc.npi.prontuario.util;

public class MessagesConstants {

}
