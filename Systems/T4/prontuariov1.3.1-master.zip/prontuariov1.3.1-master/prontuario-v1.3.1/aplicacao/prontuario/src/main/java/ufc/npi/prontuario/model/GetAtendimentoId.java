package ufc.npi.prontuario.model;

public class GetAtendimentoId {

	public static Integer getIdAtendimento(Atendimento atendimento) {
		return GetAtendimentoId.getIdAtendimento(atendimento);
	}
	
}
