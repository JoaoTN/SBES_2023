package ufc.npi.prontuario.model;

public class GetPacienteId {

	public static Integer mostrarIdPaciente(Paciente paciente) {
		return paciente.getId();
	}
	
}
