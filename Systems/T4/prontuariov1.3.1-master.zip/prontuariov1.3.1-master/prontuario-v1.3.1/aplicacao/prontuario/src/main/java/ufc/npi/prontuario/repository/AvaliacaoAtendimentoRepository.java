package ufc.npi.prontuario.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ufc.npi.prontuario.model.AvaliacaoAtendimento;

public interface AvaliacaoAtendimentoRepository extends JpaRepository<AvaliacaoAtendimento, Integer>{
	
	
	
}
