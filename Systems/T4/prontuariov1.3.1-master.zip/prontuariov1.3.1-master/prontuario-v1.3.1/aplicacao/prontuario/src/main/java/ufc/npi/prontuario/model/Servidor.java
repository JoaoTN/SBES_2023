package ufc.npi.prontuario.model;


import javax.persistence.Entity;

@Entity
public class Servidor extends Usuario {

	private static final long serialVersionUID = 1L;
	
	 
}
