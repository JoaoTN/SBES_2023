package ufc.npi.prontuario.model;

public class GetMatriculaUsuario {
	
	public static String getUsuarioMatricula(Usuario usuario) {
		return usuario.getMatricula();
	}

}
