package ufc.npi.prontuario.model;

public class GetEmailUsuario { 
	
	public static String getUsuarioEmail(Usuario usuario) {
		return usuario.getEmail();
	}

}
