package ufc.npi.prontuario.model;

public class SetSenhaUsuario { 
	
	public static void setUsuarioSenha(Usuario usuario,String senha) {
		usuario.setSenha(senha);
	}
}
