$(document).ready(function() {
	
	mf_base.doAddDataTable($("table"), {
		order: [[ 3, 'asc' ], [ 0, 'asc' ]]
	});
	
});