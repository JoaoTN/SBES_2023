$(document).ready(function() {
	
	mf_base.doAddDataTable($("table"), {
		order: [[ 1, 'asc' ]],
	});
});