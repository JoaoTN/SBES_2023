package ufc.npi.prontuario.model;

public class SetUsuarioId { 
	
	public static void setIdUsuario(Usuario usuario,Integer id) {
		usuario.setId(id);
	}

}
