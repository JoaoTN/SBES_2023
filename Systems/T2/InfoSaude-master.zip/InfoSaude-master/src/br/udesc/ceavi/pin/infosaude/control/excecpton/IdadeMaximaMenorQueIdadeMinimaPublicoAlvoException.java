package br.udesc.ceavi.pin.infosaude.control.excecpton;

public class IdadeMaximaMenorQueIdadeMinimaPublicoAlvoException extends Exception {

    public IdadeMaximaMenorQueIdadeMinimaPublicoAlvoException() {
        super("Idade Maxima É Menor Que A Idade Minima");
    }

}
