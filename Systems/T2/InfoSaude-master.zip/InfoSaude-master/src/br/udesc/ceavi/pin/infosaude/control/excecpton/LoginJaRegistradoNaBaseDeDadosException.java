package br.udesc.ceavi.pin.infosaude.control.excecpton;

public class LoginJaRegistradoNaBaseDeDadosException extends Exception{

    public LoginJaRegistradoNaBaseDeDadosException() {
        super("Login Ja Registado Na Nossa Base de Dados");
    }

    
}