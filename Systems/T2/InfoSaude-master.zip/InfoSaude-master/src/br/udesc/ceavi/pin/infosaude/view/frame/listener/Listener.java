package br.udesc.ceavi.pin.infosaude.view.frame.listener;

/**
 *
 * @author gusta
 */
public interface Listener {

	void addActionbtn0();
	void addActionbtn1();
	void addActionbtn2();
	void addActionbtn3();
	void addActionbtn4();
}
