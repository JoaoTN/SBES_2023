package br.udesc.ceavi.pin.infosaude.modelo;

/**
 *
 * @author Fábio
 */
public interface Usuario_Logado {
    public long getId();
    public String getUsuario();
    public void setEndereco(Endereco endereco);
}
