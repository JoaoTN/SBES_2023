package br.ufc.pds.interfaces;

import br.ufc.pds.model.jogador.JogadorHumano;

public interface EfeitoEspecial {

	void aplicarEfeito(JogadorHumano jogador);

}
