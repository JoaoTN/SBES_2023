package br.ufc.pds.model.campo.campo_especial;

public class ParadaLivre extends CampoEspecial {

    public ParadaLivre(int indice, int eixoX, int eixoY) {
        super("Parada Livre", indice, eixoX, eixoY);
    }
}
