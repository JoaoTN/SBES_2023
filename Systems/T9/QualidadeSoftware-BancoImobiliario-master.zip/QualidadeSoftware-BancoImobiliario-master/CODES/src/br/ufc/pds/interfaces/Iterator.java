package br.ufc.pds.interfaces;

public interface Iterator {
    Object first();
    Object next();
    boolean isDone();
}
