/*
 * The use this code commercially must only be done with permission of the author.
 * Any modification shall be advised and sent to the author.
 * The author is not responsible for any problem therefrom the use of this frameWork.
 *
 * @author Gefersom Cardoso Lima
 * Universidade Federal Fluminense - UFF - Brasil - 2010
 * Ciência da Computação
 */

package JPlay;

class InputBase
{
            public static final int DETECT_EVERY_PRESS = 0;
            public static final int DETECT_INITIAL_PRESS_ONLY = 1;
}
