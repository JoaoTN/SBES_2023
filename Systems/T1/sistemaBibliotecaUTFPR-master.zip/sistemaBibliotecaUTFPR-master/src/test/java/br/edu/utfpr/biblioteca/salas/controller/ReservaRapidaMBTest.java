package br.edu.utfpr.biblioteca.salas.controller;

/**
 *
 * @author Leonardo Baiser <lpbaiser@gmail.com>
 */
public class ReservaRapidaMBTest {

    public void test_getSalasDisponiveis() {
        ReservaRapidaMB reserva = new ReservaRapidaMB();
    }

}
